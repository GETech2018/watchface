Watch Face Format template (no Gradle project — just the WFF pieces).
Edit AndroidManifest.xml and the files under res/, replace/add PNGs in res/drawable,
then re-zip this folder (zip the *contents*, not the parent folder) and use
"Import template" in WFF Editor to build & sign it into an installable APK.

res/raw/watchface.xml   - the WFF scene: layout, text, time, complications, hands
res/values/strings.xml  - strings referenced from watchface.xml (e.g. @string/app_name)
res/xml/watch_face_info.xml - preview image + optional Flavors
res/drawable/*.png      - images, hand sprites, preview.png, background image
res/font/*.ttf|.otf     - any custom fonts referenced as @font/<name>
AndroidManifest.xml     - package name, permissions, WFF format version
